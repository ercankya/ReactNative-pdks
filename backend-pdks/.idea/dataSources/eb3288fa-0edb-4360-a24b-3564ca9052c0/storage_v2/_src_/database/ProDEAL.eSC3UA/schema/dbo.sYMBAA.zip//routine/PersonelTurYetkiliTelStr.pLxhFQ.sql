
CREATE PROCEDURE [dbo].[PersonelTurYetkiliTelStr] (@PERSONEL_TUR_ID as int, @Sonuc varchar(512)='' output)
AS 
Begin

	declare @TblTel table (Tel nvarchar(100))
	declare @TelStr varchar(512)=''
	declare @Tel varchar(11)

	insert into @TblTel (Tel)
	SELECT '0' + dbo.CepTelFormatDuzenle(ILETISIM.ILETISIM_DEGER) as ILETISIM_DEGER
	FROM DEAL_INEGOL..PERSONEL_TUR_YETKILI AS pty
	INNER JOIN DEAL_INEGOL..PERSONEL_TUR_YETKILI_DETAY as ptyd ON pty.PERSONEL_TUR_YETKILI_ID = ptyd.PERSONEL_TUR_YETKILI_ID
	INNER JOIN DEAL_INEGOL..ILETISIM_ILISKI on ILETISIM_ILISKI.ILISKI_TABLO_AD = 'KIMLIK' and ILETISIM_ILISKI.ILISKI_TABLO_KAYIT_ID = ptyd.KIMLIK_ID and isnull(ILETISIM_ILISKI.PSF_ID,0) = 0 and ILETISIM_ILISKI.ILETISIM_ID IS NOT NULL
	INNER JOIN DEAL_INEGOL..ILETISIM on ILETISIM_ILISKI.ILETISIM_ID = ILETISIM.ILETISIM_ID and isnull(ILETISIM.PSF_ID,0) = 0
	INNER JOIN DEAL_INEGOL..TUR_DETAY on ILETISIM.ILETISIM_ALT_TUR_ID = TUR_DETAY.TUR_DETAY_ID and TUR_DETAY.TUR_DEGER_KOD = 'CEPTEL'
	WHERE isnull(pty.PSF_ID,0) = 0
	AND   isnull(ptyd.PSF_ID,0) = 0
	AND   pty.SMS_TUR = 5
	AND   pty.ILISKI_TABLO_KAYIT_ID = @PERSONEL_TUR_ID


	DECLARE TblTel_Cursor CURSOR FOR
	SELECT Tel FROM @TblTel
  
	OPEN TblTel_Cursor;
  
	FETCH NEXT FROM TblTel_Cursor
	INTO @Tel

	WHILE @@FETCH_STATUS = 0
	BEGIN
		set @TelStr = @TelStr + @Tel + ','
		FETCH NEXT FROM TblTel_Cursor
		INTO @Tel;
	END  
	CLOSE TblTel_Cursor;  
	DEALLOCATE TblTel_Cursor;

	if (len(isnull(@TelStr,''))>=10)
		set @Sonuc = left(@TelStr,len(@TelStr)-1)
	else
		set @Sonuc=''
End
go


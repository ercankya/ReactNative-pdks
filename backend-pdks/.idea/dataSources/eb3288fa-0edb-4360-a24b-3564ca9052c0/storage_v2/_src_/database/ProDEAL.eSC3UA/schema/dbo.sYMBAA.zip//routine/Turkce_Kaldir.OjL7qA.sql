


CREATE FUNCTION [dbo].[Turkce_Kaldir] (@ifade NVARCHAR(max)) RETURNS NVARCHAR(max)
AS
BEGIN
DECLARE @veri NVARCHAR(max)
  set @veri = @ifade
  set @veri = REPLACE(@veri COLLATE SQL_Latin1_General_CP1_CS_AS,'İ','I')
  set @veri = REPLACE(@veri COLLATE SQL_Latin1_General_CP1_CS_AS,'ı','i')
  set @veri = REPLACE(@veri COLLATE SQL_Latin1_General_CP1_CS_AS,'Ş','S')
  set @veri = REPLACE(@veri COLLATE SQL_Latin1_General_CP1_CS_AS,'ş','s')
  set @veri = REPLACE(@veri COLLATE SQL_Latin1_General_CP1_CS_AS,'Ç','C')
  set @veri = REPLACE(@veri COLLATE SQL_Latin1_General_CP1_CS_AS,'ç','c')
  set @veri = REPLACE(@veri COLLATE SQL_Latin1_General_CP1_CS_AS,'Ö','O')
  set @veri = REPLACE(@veri COLLATE SQL_Latin1_General_CP1_CS_AS,'ö','o')
  set @veri = REPLACE(@veri COLLATE SQL_Latin1_General_CP1_CS_AS,'Ğ','G')
  set @veri = REPLACE(@veri COLLATE SQL_Latin1_General_CP1_CS_AS,'ğ','g')
  set @veri = REPLACE(@veri COLLATE SQL_Latin1_General_CP1_CS_AS,'Ü','U')
  set @veri = REPLACE(@veri COLLATE SQL_Latin1_General_CP1_CS_AS,'ü','u')
  return (@veri)
END
go


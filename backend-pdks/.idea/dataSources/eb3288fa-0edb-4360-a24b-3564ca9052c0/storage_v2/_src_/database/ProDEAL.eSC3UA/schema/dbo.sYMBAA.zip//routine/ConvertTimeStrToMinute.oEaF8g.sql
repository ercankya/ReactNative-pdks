
-- --------------------- ConvertTimeStrToMinute ---------------------------------------------
create function [dbo].[ConvertTimeStrToMinute](@TIME_STR varchar(30)) returns integer
 begin
   declare @SONUC as integer
   declare @SAAT as integer
   declare @DAKIKA as integer
   declare @SANIYE as integer

   declare cursorTime cursor for
		  select cast(Items as integer)
            from dbo.Split(@TIME_STR, ':')

   open  cursorTime
   fetch cursorTime into @SAAT
   fetch cursorTime into @DAKIKA
   fetch cursorTime into @SANIYE

   set @SONUC = (@SAAT * 60) + @DAKIKA
   close cursorTime
   deallocate cursorTime
   return @SONUC
 end
go


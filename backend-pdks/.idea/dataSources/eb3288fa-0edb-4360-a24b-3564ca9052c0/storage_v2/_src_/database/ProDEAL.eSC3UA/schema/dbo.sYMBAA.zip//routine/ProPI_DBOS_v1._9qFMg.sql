








CREATE procedure [dbo].[ProPI_DBOS_v1] (@TERMINAL_SERI varchar(32), @KART_SERI varchar(32), @ZAMAN as datetime,
							           @OLAY_TUSLAR AS varchar(100), @OLAY_SENSOR as varchar(1024), @DENEME_SAYAC as smallint) as

-- ProPI_DBOS_v1 '02c00042afd19699','3914952214',NULL,'','', 0

set nocount on

	declare @KART_ID integer;
	declare @KART_PSF integer;
	declare @KART_TC varchar(11);
	declare @KART_ATAMA_ETIKET nvarchar(100);
	declare @TERMINAL_ID integer;
	declare @ISLEM_KOD nvarchar(30);
	declare @INSERTED_OLAY table (OLAY_ID integer);
	declare @INSERTED_OLAY_ID int;
	declare @INSERTED_KART table (KART_ID integer);
	declare @INSERTED_KART_ID integer;
	--***************************
	--Parametreler
	declare @OlayDuzeltmeSure smallint = 60;
	declare @AsycnProsedurAd varchar(32) = 'ProPI_DBOS2'
	declare @TC_ILE_GIRIS_HAKKI tinyint = 99
	declare @TC_ILE_GIRIS_HAKKI_KONTROL_GUN int = 30
	--***************************
	declare @MESAJ1_METIN nvarchar(512), @MESAJ1_EXP_MS smallint, @MESAJ1_MN_MS smallint, @MESAJ1_MX_MS smallint, @MESAJ1_IDLE_METIN nvarchar(512), @MESAJ1_FLAG tinyint; --OLAY_MESAJ1
	declare @MESAJ2_METIN nvarchar(512), @MESAJ2_EXP_MS smallint, @MESAJ2_MN_MS smallint, @MESAJ2_MX_MS smallint, @MESAJ2_IDLE_METIN nvarchar(512), @MESAJ2_FLAG tinyint; --OLAY_MESAJ2
	declare @CEVAP_IO nchar(256), @CEVAP_SES_TIP tinyint, @CEVAP_SES_NFO nvarchar(512), @CEVAP_FLAG tinyint, @CEVAP_LED tinyint, @CEVAP_SQL nvarchar(1024) --OLAY_CEVAP
	declare @OLAY_INOUT tinyint;
	declare @TC_ILE_GIRIS_SAYISI int;
	declare @OLAY_PSF tinyint
	--****************************
	if (@OLAY_TUSLAR='*123*')
		set @ISLEM_KOD='KARTEKLE';
	else if (@OLAY_TUSLAR='*124*')
		set @ISLEM_KOD='KARTPSF';
	else if (@KART_SERI='1') --Cihaz aktif mi tetiğidir
		set @ISLEM_KOD='KONTROL';
	else if (@KART_SERI='2') --Cihaz reset tetiğidir
		set @ISLEM_KOD='RESET';
	else if (@KART_SERI='' and @OLAY_TUSLAR='') --Cihaz ayar tetiğidir
		set @ISLEM_KOD='AYAR';
	else
		set @ISLEM_KOD='';
	--****************************
	if (year(isnull(@ZAMAN,'')) < 2020)
		set @ZAMAN = getdate();
	--****************************
	update TERMINAL set TERMINAL_SON_HAREKET_ZAMAN = getdate() from TERMINAL where TERMINAL_SERI = @TERMINAL_SERI;
	--****************************
	if (@ISLEM_KOD = '') -- OLAY ekle
		begin
		--*****************************************************************************
		select @TC_ILE_GIRIS_SAYISI = count(OLAY_ID)
		from OLAY
		inner join KART_ATAMA on KART_ATAMA.KART_ID = OLAY.OLAY_KART_ID and KART_ILISKI_TURU = 1 and OLAY_ZAMAN between KART_ATAMA.ATAMA_BASLANGIC_ZAMANI and KART_ATAMA.ATAMA_BITIS_ZAMANI
		where isnull(OLAY.PSF,0) = 0
		and   OLAY_KAYIT_ZAMAN between dateadd(day, -1 * @TC_ILE_GIRIS_HAKKI_KONTROL_GUN, getdate()) and  getdate()
		and   OLAY_KAYIT_ZAMAN not between dateadd(second, -1 * @OlayDuzeltmeSure, getdate()) and  getdate()
		and   OLAY.OLAY_TUSLAR = @OLAY_TUSLAR
		and   len(OLAY.OLAY_TUSLAR) = 11
		and   OLAY.OLAY_ID > 6201;
		--*****************************************************************************
		set @OLAY_PSF = case when @TC_ILE_GIRIS_SAYISI >= @TC_ILE_GIRIS_HAKKI then 1 end;
		--*****************************************************************************
		insert into OLAY
				(PSF, OLAY_ZAMAN, OLAY_TERMINAL_SERI, OLAY_SERI, OLAY_TUSLAR, OLAY_SENSOR, OLAY_SAYAC, OLAY_KAYIT_ZAMAN, OLAY_INOUT, OLAY_INOUT_FLAG)
		output inserted.OLAY_ID
		into @INSERTED_OLAY
		values  (@OLAY_PSF, @ZAMAN, @TERMINAL_SERI, @KART_SERI, @OLAY_TUSLAR, @OLAY_SENSOR, @DENEME_SAYAC, GETDATE(), 0, 1);
		--******************************************
		select @INSERTED_OLAY_ID = OLAY_ID from @INSERTED_OLAY;
		--*****************************************************************************
		if (isnull(@INSERTED_OLAY_ID,0)>0)
			begin
			--*****************************************************************************
			select top (1) @KART_ID = KART.KART_ID, @KART_PSF = KART.KART_PSF
			from KART (nolock)
			left join KART_ATAMA (nolock) on KART_ATAMA.KART_ID = KART.KART_ID and isnull(KART_ATAMA.KART_ILISKI_TURU,1) = 1
			where (KART_SERI = @KART_SERI or KART_ATAMA.KART_ILISKI_ID = @OLAY_TUSLAR)
			and   @ZAMAN between ATAMA_BASLANGIC_ZAMANI	and ATAMA_BITIS_ZAMANI
			and   isnull(KART_ATAMA.KART_ILISKI_TURU,1) = 1;
			--**************************
			if (@KART_ID is null)
				begin
				select top (1) @KART_ID = KART.KART_ID, @KART_PSF = KART.KART_PSF
				from KART (nolock)
				left join KART_ATAMA (nolock) on KART_ATAMA.KART_ID = KART.KART_ID and isnull(KART_ATAMA.KART_ILISKI_TURU,1) = 4
				where KART_ATAMA.KART_ILISKI_ID = @KART_SERI
				and   @ZAMAN between ATAMA_BASLANGIC_ZAMANI	and ATAMA_BITIS_ZAMANI
				and   isnull(KART_ATAMA.KART_ILISKI_TURU,1) = 4;
				end
			--******************************************
			select @TERMINAL_ID = TERMINAL_ID from TERMINAL (nolock) where TERMINAL_SERI = @TERMINAL_SERI;
			--*****************************************************************************
			update OLAY set OLAY_KART_ID = @KART_ID, OLAY_TERMINAL_ID = @TERMINAL_ID, OLAY_KART_PSF = @KART_PSF from OLAY where OLAY_ID = @INSERTED_OLAY_ID;
			--*****************************************************************************
			if (isnull(@KART_ID,0)>0 and isnull(@OLAY_PSF,0) <> 1)
				begin
				if (isnull(@KART_PSF,0)=0)
					begin
						--*****************************************************************************
						select top (1) @KART_TC = KART_ILISKI_ID, @KART_ATAMA_ETIKET = KART_ATAMA_ETIKET from KART_ATAMA (nolock) where KART_ID = @KART_ID and @ZAMAN between ATAMA_BASLANGIC_ZAMANI and ATAMA_BITIS_ZAMANI and isnull(KART_ILISKI_TURU,1) = 1;
						--*****************************************************************************
						if (len(isnull(@KART_TC,0)) = 11)
							begin
							--*****************************************************************************
							-- Son OLAY ı bul ve tersini at
							select @OLAY_INOUT = 1 - isnull(OLAY_INOUT,1)
							from OLAY (nolock)
							where OLAY_ID  = (select MAX(OLAY_ID) AS OLAY_ID
												from OLAY (nolock)
												where OLAY_ID < @INSERTED_OLAY_ID
												and   OLAY.OLAY_KART_ID = @KART_ID
												and   isnull(OLAY.PSF,0) = 0
												and   cast(OLAY_ZAMAN as date) = cast(getdate() as date));
							--********************************************************
							update OLAY set OLAY_INOUT = isnull(@OLAY_INOUT,0) from OLAY where OLAY_ID = @INSERTED_OLAY_ID;
							--********************************************************
							select	@MESAJ1_METIN = case @OLAY_INOUT when 1 then 'GULE GULE' else 'HOSGELDINIZ' end + case when len(@OLAY_TUSLAR) = 11 then ' K:' + cast(case when @TC_ILE_GIRIS_HAKKI - @TC_ILE_GIRIS_SAYISI > 0 then @TC_ILE_GIRIS_HAKKI - @TC_ILE_GIRIS_SAYISI - 1 else 0 end as varchar) else '' end,
									@MESAJ1_EXP_MS = 1000, @MESAJ1_MN_MS = 1000, @MESAJ1_MX_MS = 3000, @MESAJ1_IDLE_METIN = '<tarih>', @MESAJ1_FLAG = 0;
							select	@MESAJ2_METIN = dbo.Turkce_Kaldir(isnull(@KART_ATAMA_ETIKET, @KART_ID)),
									@MESAJ2_EXP_MS = 1000, @MESAJ2_MN_MS = 1000, @MESAJ2_MX_MS = 3000, @MESAJ2_IDLE_METIN = '<saat>', @MESAJ2_FLAG = 0;
							select	@CEVAP_IO = '', @CEVAP_SES_TIP = case @OLAY_INOUT when 1 then 4 else 3 end, @CEVAP_SES_NFO = '', @CEVAP_FLAG = 1, @CEVAP_LED = 1,
									@CEVAP_SQL = 'exec ' + @AsycnProsedurAd + ' ' + cast(@INSERTED_OLAY_ID as varchar);
							--*****************************************************************************
							end
						else
							begin
							select	@MESAJ1_METIN = 'TCNO BULUNAMADI',
									@MESAJ1_EXP_MS = 1000, @MESAJ1_MN_MS = 1000, @MESAJ1_MX_MS = 3000, @MESAJ1_IDLE_METIN = '<tarih>', @MESAJ1_FLAG = 0;
							select	@MESAJ2_METIN = dbo.Turkce_Kaldir(isnull(@KART_ATAMA_ETIKET, @KART_ID)),
									@MESAJ2_EXP_MS = 1000, @MESAJ2_MN_MS = 1000, @MESAJ2_MX_MS = 3000, @MESAJ2_IDLE_METIN = '<saat>', @MESAJ2_FLAG = 0;
							select	@CEVAP_IO = '', @CEVAP_SES_TIP = 1, @CEVAP_SES_NFO = '', @CEVAP_FLAG = 0, @CEVAP_LED = 2,
									@CEVAP_SQL = '';
							end
					end
				else
					begin
					select	@MESAJ1_METIN = 'KART PASIFTIR',
							@MESAJ1_EXP_MS = 1000, @MESAJ1_MN_MS = 1000, @MESAJ1_MX_MS = 3000, @MESAJ1_IDLE_METIN = '<tarih>', @MESAJ1_FLAG = 0;
					select	@MESAJ2_METIN = @KART_ID,
							@MESAJ2_EXP_MS = 1000, @MESAJ2_MN_MS = 1000, @MESAJ2_MX_MS = 3000, @MESAJ2_IDLE_METIN = '<saat>', @MESAJ2_FLAG = 0;
					select	@CEVAP_IO = '', @CEVAP_SES_TIP = 2, @CEVAP_SES_NFO = '', @CEVAP_FLAG = 0, @CEVAP_LED = 3,
							@CEVAP_SQL = '';
					--********************************************************
					update OLAY set PSF = 1 from OLAY where OLAY_ID = @INSERTED_OLAY_ID;
					--********************************************************
					end
				end
			else
				begin
				if (@TC_ILE_GIRIS_SAYISI >= @TC_ILE_GIRIS_HAKKI and @OLAY_PSF = 1)
					begin
					select	@MESAJ1_METIN = 'TC GIRIS HAK: 00',
							@MESAJ1_EXP_MS = 1000, @MESAJ1_MN_MS = 1000, @MESAJ1_MX_MS = 3000, @MESAJ1_IDLE_METIN = '<tarih>', @MESAJ1_FLAG = 0;
					select	@MESAJ2_METIN = '',
							@MESAJ2_EXP_MS = 1000, @MESAJ2_MN_MS = 1000, @MESAJ2_MX_MS = 3000, @MESAJ2_IDLE_METIN = '<saat>', @MESAJ2_FLAG = 0;
					select	@CEVAP_IO = '', @CEVAP_SES_TIP = 1, @CEVAP_SES_NFO = '', @CEVAP_FLAG = 0, @CEVAP_LED = 2,
							@CEVAP_SQL = '';
					--********************************************************
					update OLAY set PSF = 1 from OLAY where OLAY_ID = @INSERTED_OLAY_ID;
					--********************************************************
					end
				else if (isnull(@OLAY_TUSLAR,'')<>'')
					begin
					select	@MESAJ1_METIN = 'GECERSIZ TUS',
							@MESAJ1_EXP_MS = 1000, @MESAJ1_MN_MS = 1000, @MESAJ1_MX_MS = 3000, @MESAJ1_IDLE_METIN = '<tarih>', @MESAJ1_FLAG = 0;
					select	@MESAJ2_METIN = '',
							@MESAJ2_EXP_MS = 1000, @MESAJ2_MN_MS = 1000, @MESAJ2_MX_MS = 3000, @MESAJ2_IDLE_METIN = '<saat>', @MESAJ2_FLAG = 0;
					select	@CEVAP_IO = '', @CEVAP_SES_TIP = 1, @CEVAP_SES_NFO = '', @CEVAP_FLAG = 0, @CEVAP_LED = 2,
							@CEVAP_SQL = '';
					--********************************************************
					update OLAY set PSF = 1 from OLAY where OLAY_ID = @INSERTED_OLAY_ID;
					--********************************************************
					end
				else
					begin
					select	@MESAJ1_METIN = 'KART BULUNAMADI',
							@MESAJ1_EXP_MS = 1000, @MESAJ1_MN_MS = 1000, @MESAJ1_MX_MS = 3000, @MESAJ1_IDLE_METIN = '<tarih>', @MESAJ1_FLAG = 0;
					select	@MESAJ2_METIN = '',
							@MESAJ2_EXP_MS = 1000, @MESAJ2_MN_MS = 1000, @MESAJ2_MX_MS = 3000, @MESAJ2_IDLE_METIN = '<saat>', @MESAJ2_FLAG = 0;
					select	@CEVAP_IO = '', @CEVAP_SES_TIP = 1, @CEVAP_SES_NFO = '', @CEVAP_FLAG = 0, @CEVAP_LED = 2,
							@CEVAP_SQL = '';
					--********************************************************
					update OLAY set PSF = 1 from OLAY where OLAY_ID = @INSERTED_OLAY_ID;
					--********************************************************
					end
				end
			end
		end
	--*******************************************************************************
	else if (@ISLEM_KOD = 'KARTEKLE') -- Kart ekle
		begin
		--************************************
		select @KART_ID = KART_ID from KART (nolock) where KART_SERI = @KART_SERI;
		--************************************
		if (isnull(@KART_ID,0)>0)
			begin
			select	@MESAJ1_METIN = 'KART MEVCUT',
					@MESAJ1_EXP_MS = 1000, @MESAJ1_MN_MS = 1000, @MESAJ1_MX_MS = 3000, @MESAJ1_IDLE_METIN = '<tarih>', @MESAJ1_FLAG = 0;
			select	@MESAJ2_METIN = @KART_ID,
					@MESAJ2_EXP_MS = 1000, @MESAJ2_MN_MS = 1000, @MESAJ2_MX_MS = 3000, @MESAJ2_IDLE_METIN = '<saat>', @MESAJ2_FLAG = 0;
			select	@CEVAP_IO = '', @CEVAP_SES_TIP = 2, @CEVAP_SES_NFO = '', @CEVAP_FLAG = 0, @CEVAP_LED = 3,
					@CEVAP_SQL = '';
			end
		else
			begin
			--************************************
			insert into KART
					(KART_SERI)
					output inserted.KART_ID
					into @INSERTED_KART
					values (@KART_SERI);
			--***************************
			select @INSERTED_KART_ID = KART_ID from @INSERTED_KART;
			--************************************
			if (isnull(@INSERTED_KART_ID,0)>0)
				begin
					select	@MESAJ1_METIN = 'KART KAYDEDILDI',
							@MESAJ1_EXP_MS = 1000, @MESAJ1_MN_MS = 1000, @MESAJ1_MX_MS = 3000, @MESAJ1_IDLE_METIN = '<tarih>', @MESAJ1_FLAG = 0;
					select	@MESAJ2_METIN = @INSERTED_KART_ID,
							@MESAJ2_EXP_MS = 1000, @MESAJ2_MN_MS = 1000, @MESAJ2_MX_MS = 3000, @MESAJ2_IDLE_METIN = '<saat>', @MESAJ2_FLAG = 0;
					select	@CEVAP_IO = '', @CEVAP_SES_TIP = 0, @CEVAP_SES_NFO = '', @CEVAP_FLAG = 0, @CEVAP_LED = 1,
							@CEVAP_SQL = '';
				end
			end
		end
	--*******************************************************************************
	else if (@ISLEM_KOD = 'KARTPSF') -- Kart pasif yap
		begin
		--************************************
		select @KART_ID = KART_ID from KART (nolock) where KART_SERI = @KART_SERI;
		--************************************
		if (isnull(@KART_ID,0)>0)
			begin
			--************************************
			update KART set KART_PSF = 1 from KART where KART_ID = @KART_ID;
			--************************************
			select	@MESAJ1_METIN = 'KART PSF YAPILDI',
					@MESAJ1_EXP_MS = 1000, @MESAJ1_MN_MS = 1000, @MESAJ1_MX_MS = 3000, @MESAJ1_IDLE_METIN = '<tarih>', @MESAJ1_FLAG = 0;
			select	@MESAJ2_METIN = @KART_ID,
					@MESAJ2_EXP_MS = 1000, @MESAJ2_MN_MS = 1000, @MESAJ2_MX_MS = 3000, @MESAJ2_IDLE_METIN = '<saat>', @MESAJ2_FLAG = 0;
			select	@CEVAP_IO = '', @CEVAP_SES_TIP = 0, @CEVAP_SES_NFO = '', @CEVAP_FLAG = 0, @CEVAP_LED = 1,
					@CEVAP_SQL = '';
			end
		else
			begin
			select	@MESAJ1_METIN = 'KART BULUNAMADI',
					@MESAJ1_EXP_MS = 1000, @MESAJ1_MN_MS = 1000, @MESAJ1_MX_MS = 3000, @MESAJ1_IDLE_METIN = '<tarih>', @MESAJ1_FLAG = 0;
			select	@MESAJ2_METIN = '',
					@MESAJ2_EXP_MS = 1000, @MESAJ2_MN_MS = 1000, @MESAJ2_MX_MS = 3000, @MESAJ2_IDLE_METIN = '<saat>', @MESAJ2_FLAG = 0;
			select	@CEVAP_IO = '', @CEVAP_SES_TIP = 1, @CEVAP_SES_NFO = '', @CEVAP_FLAG = 0, @CEVAP_LED = 2,
					@CEVAP_SQL = '';
			end
		end
	--*******************************************************************************
	else if (@ISLEM_KOD = 'AYAR')
		begin
		--************************************
		insert into OLAY
				(PSF, OLAY_ZAMAN, OLAY_TERMINAL_SERI, OLAY_SERI, OLAY_TUSLAR, OLAY_SENSOR, OLAY_SAYAC, OLAY_KAYIT_ZAMAN, OLAY_INOUT, OLAY_INOUT_FLAG)
		output inserted.OLAY_ID
		into @INSERTED_OLAY
		values  (1, @ZAMAN, @TERMINAL_SERI, @KART_SERI, @OLAY_TUSLAR, @OLAY_SENSOR, @DENEME_SAYAC, GETDATE(), NULL, NULL);
		--******************************************
		select @INSERTED_OLAY_ID = OLAY_ID from @INSERTED_OLAY;
		--************************************
		select @TERMINAL_ID = TERMINAL_ID from TERMINAL (nolock) where TERMINAL_SERI = @TERMINAL_SERI;
		--************************************
		update OLAY set OLAY_TERMINAL_ID = @TERMINAL_ID from OLAY where OLAY_ID = @INSERTED_OLAY_ID;
		--************************************
		select	@MESAJ1_METIN = '',
				@MESAJ1_EXP_MS = 0, @MESAJ1_MN_MS = 0, @MESAJ1_MX_MS = 0, @MESAJ1_IDLE_METIN = '<tarih>', @MESAJ1_FLAG = 0;
		select	@MESAJ2_METIN = '',
				@MESAJ2_EXP_MS = 0, @MESAJ2_MN_MS = 0, @MESAJ2_MX_MS = 0, @MESAJ2_IDLE_METIN = '<saat>', @MESAJ2_FLAG = 0;
		select	@CEVAP_IO = '', @CEVAP_SES_TIP = 0, @CEVAP_SES_NFO = '', @CEVAP_FLAG = 0, @CEVAP_LED = 0,
				@CEVAP_SQL = '';
		--************************************
		end
	--*******************************************************************************
	else if (@ISLEM_KOD = 'RESET')
		begin
		--************************************
		insert into OLAY
				(PSF, OLAY_ZAMAN, OLAY_TERMINAL_SERI, OLAY_SERI, OLAY_TUSLAR, OLAY_SENSOR, OLAY_SAYAC, OLAY_KAYIT_ZAMAN, OLAY_INOUT, OLAY_INOUT_FLAG)
		output inserted.OLAY_ID
		into @INSERTED_OLAY
		values  (1, @ZAMAN, @TERMINAL_SERI, @KART_SERI, @OLAY_TUSLAR, @OLAY_SENSOR, @DENEME_SAYAC, GETDATE(), NULL, NULL);
		--******************************************
		select @INSERTED_OLAY_ID = OLAY_ID from @INSERTED_OLAY;
		--************************************
		select @TERMINAL_ID = TERMINAL_ID from TERMINAL (nolock) where TERMINAL_SERI = @TERMINAL_SERI;
		update OLAY set OLAY_TERMINAL_ID = @TERMINAL_ID from OLAY where OLAY_ID = @INSERTED_OLAY_ID;
		set @INSERTED_OLAY_ID = 0;
		--************************************
		declare @Msg nvarchar(max) 
		set @Msg = '*** Cihaz Resetlendi (192.168.12.4\sql2012) ***' + char(13) + char(10) + 'Terminal Seri: ' + @TERMINAL_SERI
		exec [TeleMesaj] '-420981850', @Msg, '1042706355:AAGagahYtvK1sF-t4iVw8i_bwLQ2iDCTN34';
		--************************************
		end
	--*******************************************************************************
	if (isnull(@INSERTED_OLAY_ID,0)>0)
		begin
		--************************************
		insert into OLAY_MESAJ
				(MESAJ_OLAY_ID, MESAJ_ZAMAN, MESAJ_METIN, MESAJ_EXP_MS, MESAJ_MN_MS, MESAJ_MX_MS, MESAJ_IDLE_METIN, MESAJ_FLAG)
		select	@INSERTED_OLAY_ID, getdate(), @MESAJ1_METIN, @MESAJ1_EXP_MS, @MESAJ1_MN_MS, @MESAJ1_MX_MS, @MESAJ1_IDLE_METIN, @MESAJ1_FLAG
		union all
		select	@INSERTED_OLAY_ID, getdate(), @MESAJ2_METIN, @MESAJ2_EXP_MS, @MESAJ2_MN_MS, @MESAJ2_MX_MS, @MESAJ2_IDLE_METIN, @MESAJ2_FLAG;
		--************************************
		insert into OLAY_CEVAP
				(CEVAP_OLAY_ID, CEVAP_ZAMAN, CEVAP_IO, CEVAP_SES_TIP, CEVAP_SES_NFO, CEVAP_FLAG, CEVAP_LED, CEVAP_SQL)
		select	@INSERTED_OLAY_ID, getdate(), @CEVAP_IO, @CEVAP_SES_TIP, @CEVAP_SES_NFO, @CEVAP_FLAG, @CEVAP_LED,
				@CEVAP_SQL;
		--*******************************************************************************
		select	'{
					"Mesaj1": {
						"MESAJ_METIN": {
							"Text": "' + isnull(@MESAJ1_METIN,'') + '"
						},
						"MESAJ_EXP_MS": "' + cast(@MESAJ1_EXP_MS as varchar) + '",
						"MESAJ_MN_MS": "' + cast(@MESAJ1_MN_MS as varchar) + '",
						"MESAJ_MX_MS": "' + cast(@MESAJ1_MX_MS as varchar) + '",
						"MESAJ_IDLE_METIN": {
							"Text": "' + isnull(@MESAJ1_IDLE_METIN,'') + '"
						},
						"MESAJ_FLAG": "' + cast(@MESAJ1_FLAG as varchar) + '"
					},
					"Mesaj2": {
						"MESAJ_METIN": {
							"Text": "' + isnull(@MESAJ2_METIN,'') + '"
						},
						"MESAJ_EXP_MS": "' + cast(@MESAJ2_EXP_MS as varchar) + '",
						"MESAJ_MN_MS": "' + cast(@MESAJ2_MN_MS as varchar) + '",
						"MESAJ_MX_MS": "' + cast(@MESAJ2_MX_MS as varchar) + '",
						"MESAJ_IDLE_METIN": {
							"Text": "' + isnull(@MESAJ2_IDLE_METIN,'') + '"
						},
						"MESAJ_FLAG": "' + cast(@MESAJ2_FLAG as varchar) + '"
					},
					"Mesaj3": {
						"MESAJ_METIN": {
							"Text": "' + isnull(@MESAJ1_METIN,'') + ' /// ' + isnull(@MESAJ2_METIN,'') + '"
						},
						"MESAJ_EXP_MS": "' + cast(@MESAJ2_EXP_MS as varchar) + '",
						"MESAJ_MN_MS": "' + cast(@MESAJ2_MN_MS as varchar) + '",
						"MESAJ_MX_MS": "' + cast(@MESAJ2_MX_MS as varchar) + '",
						"MESAJ_IDLE_METIN": {
							"Text": "' + isnull(@MESAJ2_IDLE_METIN,'') + '"
						},
						"MESAJ_FLAG": "' + cast(@MESAJ2_FLAG as varchar) + '"
					},
				}' as Mesaj_JSON,
		getdate() as CEVAP_ZAMAN,
		@CEVAP_IO as CEVAP_IO,
		@CEVAP_SES_TIP as CEVAP_SES_TIP,
		@CEVAP_SES_NFO as CEVAP_SES_NFO,
		@CEVAP_FLAG as CEVAP_FLAG,
		@CEVAP_LED as CEVAP_LED,
		@CEVAP_SQL as CEVAP_SQL;
		--*******************************************************************************
		end

go


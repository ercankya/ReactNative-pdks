



CREATE procedure [dbo].[ProPI_DBOS] (@TERMINAL_SERI varchar(32), @KART_SERI varchar(32), @ZAMAN as datetime,
							        @OLAY_TUSLAR AS varchar(100), @OLAY_SENSOR as varchar(1024), @DENEME_SAYAC as smallint) as

-- ProPI_DBOS '02c0014203085f87111','1111',NULL,'','', 0

set nocount on

declare @KART_ID int
declare @KART_PSF int
declare @KART_TC varchar(11)
declare @KART_ATAMA_ETIKET nvarchar(100)
declare @TERMINAL_ID int
declare @ISLEM_KOD nvarchar(30)
declare @INSERTED_OLAY table (OLAY_ID int)
declare @INSERTED_OLAY_ID int
declare @INSERTED_KART table (KART_ID int)
declare @INSERTED_KART_ID int
declare @COVID_SONUC tinyint
declare @MESAJ_STR nvarchar(500)
declare @MESAJ1_METIN nvarchar(512), @MESAJ1_EXP_MS smallint, @MESAJ1_MN_MS smallint, @MESAJ1_MX_MS smallint, @MESAJ1_IDLE_METIN nvarchar(512), @MESAJ1_FLAG tinyint --OLAY_MESAJ1
declare @MESAJ2_METIN nvarchar(512), @MESAJ2_EXP_MS smallint, @MESAJ2_MN_MS smallint, @MESAJ2_MX_MS smallint, @MESAJ2_IDLE_METIN nvarchar(512), @MESAJ2_FLAG tinyint --OLAY_MESAJ2
declare @CEVAP_IO nchar(256), @CEVAP_SES_TIP tinyint, @CEVAP_SES_NFO nvarchar(512), @CEVAP_FLAG tinyint, @CEVAP_LED tinyint --OLAY_CEVAP

	if (@OLAY_TUSLAR='*123*') begin
		set @ISLEM_KOD='KARTEKLE' end
	else if (@OLAY_TUSLAR='*124*') begin
		set @ISLEM_KOD='KARTPSF' end
	else begin
		set @ISLEM_KOD='' end

	if (year(isnull(@ZAMAN,'')) < 2020) begin
		set @ZAMAN = getdate() end

	--*******************************************************************************
	if (isnull(@ISLEM_KOD,'') ='') -- OLAY ekle
	begin

		insert into OLAY
				(OLAY_ZAMAN, OLAY_TERMINAL_SERI, OLAY_SERI, OLAY_TUSLAR, OLAY_SENSOR, OLAY_SAYAC, OLAY_KAYIT_ZAMAN)
		output inserted.OLAY_ID
		into @INSERTED_OLAY
		values  (@ZAMAN, @TERMINAL_SERI, @KART_SERI, @OLAY_TUSLAR, @OLAY_SENSOR, @DENEME_SAYAC, GETDATE())
		
		select @INSERTED_OLAY_ID = OLAY_ID from @INSERTED_OLAY

		if (isnull(@INSERTED_OLAY_ID,0)>0)
			begin
				select @KART_ID = KART_ID, @KART_PSF = KART_PSF from KART (nolock) where KART_SERI = @KART_SERI
				select @TERMINAL_ID = TERMINAL_ID from TERMINAL (nolock) where TERMINAL_SERI = @TERMINAL_SERI
				update OLAY set OLAY_KART_ID = @KART_ID, OLAY_TERMINAL_ID = @TERMINAL_ID, OLAY_KART_PSF = @KART_PSF from OLAY where OLAY_ID = @INSERTED_OLAY_ID

				if (isnull(@KART_ID,0)>0)
					begin
						if (isnull(@KART_PSF,0)=0)
							begin
								select @KART_TC = KART_ILISKI_ID, @KART_ATAMA_ETIKET = KART_ATAMA_ETIKET from KART_ATAMA (nolock) where KART_ID = @KART_ID and getdate() between ATAMA_BASLANGIC_ZAMANI and ATAMA_BITIS_ZAMANI
								
								--if (len(isnull(@KART_TC,0))=11)
								--	begin
								--		set @COVID_SONUC = 0
								--		exec [TEPEBASI_HASTAM].[dbo].[GetHastaTemasDurumu] @HastaKimlikNo = @KART_TC, @SonucKodu = @COVID_SONUC output
								--	end

									select	@MESAJ1_METIN = CASE @COVID_SONUC WHEN 2 THEN 'TEMAS' WHEN 3 THEN 'HATA' ELSE 'ONAY' END + ' - ' + 'BASARILI',
											@MESAJ1_EXP_MS = 1000, @MESAJ1_MN_MS = 1000, @MESAJ1_MX_MS = 1000, @MESAJ1_IDLE_METIN = '<tarih>', @MESAJ1_FLAG = 0
									select	@MESAJ2_METIN = dbo.Turkce_Kaldir(isnull(@KART_ATAMA_ETIKET, @KART_ID)),
											@MESAJ2_EXP_MS = 1000, @MESAJ2_MN_MS = 1000, @MESAJ2_MX_MS = 1000, @MESAJ2_IDLE_METIN = '<saat>', @MESAJ2_FLAG = 0
									select	@CEVAP_IO = '', @CEVAP_SES_TIP = 1, @CEVAP_SES_NFO = '', @CEVAP_FLAG = 1, @CEVAP_LED = CASE @COVID_SONUC WHEN 2 THEN 3 ELSE 1 END

								--if (@COVID_SONUC=2)
								--begin
								--	set @MESAJ_STR = @KART_TC + ' - ' + dbo.Turkce_Kaldir(isnull(@KART_ATAMA_ETIKET,'(Ad/Soyad bulunamadı)')) + ' Temas tespit edildi';
								--	exec [TEPEBASI_HASTAM].[dbo].[TeleMesaj] @Mesaj = @MESAJ_STR, @ChatID ='-1001283510321'
								--	--exec [TEPEBASI_HASTAM].[dbo].[SmsGonder] @Mesaj = @MESAJ_STR, @Tel='05325046290,05056160859,05453591133,05536043865' --Burak ın gönderdiği nolar
								--	--exec [TEPEBASI_HASTAM].[dbo].[SmsGonder] @Mesaj = @MESAJ_STR, @Tel='05536124070' --Ahmet
								--end
							end
						else
							begin
								select	@MESAJ1_METIN = 'KART PASIFTIR',
										@MESAJ1_EXP_MS = 1000, @MESAJ1_MN_MS = 1000, @MESAJ1_MX_MS = 1000, @MESAJ1_IDLE_METIN = '<tarih>', @MESAJ1_FLAG = 0
								select	@MESAJ2_METIN = @KART_ID,
										@MESAJ2_EXP_MS = 1000, @MESAJ2_MN_MS = 1000, @MESAJ2_MX_MS = 1000, @MESAJ2_IDLE_METIN = '<saat>', @MESAJ2_FLAG = 0
								select	@CEVAP_IO = '', @CEVAP_SES_TIP = 1, @CEVAP_SES_NFO = '', @CEVAP_FLAG = 0, @CEVAP_LED = 3
							end
					end
				else
					if (@KART_SERI='')
						begin
							select	@MESAJ1_METIN = '',
									@MESAJ1_EXP_MS = 0, @MESAJ1_MN_MS = 0, @MESAJ1_MX_MS = 0, @MESAJ1_IDLE_METIN = '<tarih>', @MESAJ1_FLAG = 0
							select	@MESAJ2_METIN = '',
									@MESAJ2_EXP_MS = 0, @MESAJ2_MN_MS = 0, @MESAJ2_MX_MS = 0, @MESAJ2_IDLE_METIN = '<saat>', @MESAJ2_FLAG = 0
							select	@CEVAP_IO = '', @CEVAP_SES_TIP = 0, @CEVAP_SES_NFO = '', @CEVAP_FLAG = 0, @CEVAP_LED = 0
						end
					else
						begin
							select	@MESAJ1_METIN = 'KART BULUNAMADI',
									@MESAJ1_EXP_MS = 1000, @MESAJ1_MN_MS = 1000, @MESAJ1_MX_MS = 1000, @MESAJ1_IDLE_METIN = '<tarih>', @MESAJ1_FLAG = 0
							select	@MESAJ2_METIN = '',
									@MESAJ2_EXP_MS = 1000, @MESAJ2_MN_MS = 1000, @MESAJ2_MX_MS = 1000, @MESAJ2_IDLE_METIN = '<saat>', @MESAJ2_FLAG = 0
							select	@CEVAP_IO = '', @CEVAP_SES_TIP = 2, @CEVAP_SES_NFO = '', @CEVAP_FLAG = 0, @CEVAP_LED = 2
						end
			end
	end
	--*******************************************************************************
	else if (isnull(@ISLEM_KOD,'') ='KARTEKLE') -- Kart ekle
	begin
		
		select @KART_ID = KART_ID from KART (nolock) where KART_SERI = @KART_SERI

		if (isnull(@KART_ID,0)>0)
			begin
				select	@MESAJ1_METIN = 'KART MEVCUT',
						@MESAJ1_EXP_MS = 1000, @MESAJ1_MN_MS = 1000, @MESAJ1_MX_MS = 1000, @MESAJ1_IDLE_METIN = '<tarih>', @MESAJ1_FLAG = 0
				select	@MESAJ2_METIN = @KART_ID,
						@MESAJ2_EXP_MS = 1000, @MESAJ2_MN_MS = 1000, @MESAJ2_MX_MS = 1000, @MESAJ2_IDLE_METIN = '<saat>', @MESAJ2_FLAG = 0
				select	@CEVAP_IO = '', @CEVAP_SES_TIP = 1, @CEVAP_SES_NFO = '', @CEVAP_FLAG = 0, @CEVAP_LED = 3
			end
		else
			begin
				insert into KART
						(KART_SERI)
						output inserted.KART_ID
						into @INSERTED_KART
						values (@KART_SERI)
		
				select @INSERTED_KART_ID = KART_ID from @INSERTED_KART
		
				if (isnull(@INSERTED_KART_ID,0)>0)
					begin
						select	@MESAJ1_METIN = 'KART KAYDEDILDI',
								@MESAJ1_EXP_MS = 1000, @MESAJ1_MN_MS = 1000, @MESAJ1_MX_MS = 1000, @MESAJ1_IDLE_METIN = '<tarih>', @MESAJ1_FLAG = 0
						select	@MESAJ2_METIN = @INSERTED_KART_ID,
								@MESAJ2_EXP_MS = 1000, @MESAJ2_MN_MS = 1000, @MESAJ2_MX_MS = 1000, @MESAJ2_IDLE_METIN = '<saat>', @MESAJ2_FLAG = 0
						select	@CEVAP_IO = '', @CEVAP_SES_TIP = 2, @CEVAP_SES_NFO = '', @CEVAP_FLAG = 0, @CEVAP_LED = 1
					end
		end
	end
	--*******************************************************************************
	else if (isnull(@ISLEM_KOD,'') ='KARTPSF') -- Kart pasif yap
	begin
		
		select @KART_ID = KART_ID from KART (nolock) where KART_SERI = @KART_SERI

		if (isnull(@KART_ID,0)>0)
			begin
				update KART set KART_PSF = 1
						from KART where KART_ID = @KART_ID
				select	@MESAJ1_METIN = 'KART PSF YAPILDI',
						@MESAJ1_EXP_MS = 1000, @MESAJ1_MN_MS = 1000, @MESAJ1_MX_MS = 1000, @MESAJ1_IDLE_METIN = '<tarih>', @MESAJ1_FLAG = 0
				select	@MESAJ2_METIN = @KART_ID,
						@MESAJ2_EXP_MS = 1000, @MESAJ2_MN_MS = 1000, @MESAJ2_MX_MS = 1000, @MESAJ2_IDLE_METIN = '<saat>', @MESAJ2_FLAG = 0
				select	@CEVAP_IO = '', @CEVAP_SES_TIP = 2, @CEVAP_SES_NFO = '', @CEVAP_FLAG = 0, @CEVAP_LED = 1
			end
		else
			begin
				select	@MESAJ1_METIN = 'KART BULUNAMADI',
						@MESAJ1_EXP_MS = 1000, @MESAJ1_MN_MS = 1000, @MESAJ1_MX_MS = 1000, @MESAJ1_IDLE_METIN = '<tarih>', @MESAJ1_FLAG = 0
				select	@MESAJ2_METIN = '',
						@MESAJ2_EXP_MS = 1000, @MESAJ2_MN_MS = 1000, @MESAJ2_MX_MS = 1000, @MESAJ2_IDLE_METIN = '<saat>', @MESAJ2_FLAG = 0
				select	@CEVAP_IO = '', @CEVAP_SES_TIP = 2, @CEVAP_SES_NFO = '', @CEVAP_FLAG = 0, @CEVAP_LED = 2
			end
	end

	--*******************************************************************************
	insert into OLAY_MESAJ
			(MESAJ_OLAY_ID, MESAJ_ZAMAN, MESAJ_METIN, MESAJ_EXP_MS, MESAJ_MN_MS, MESAJ_MX_MS, MESAJ_IDLE_METIN, MESAJ_FLAG)
	select	@INSERTED_OLAY_ID, getdate(), @MESAJ1_METIN, @MESAJ1_EXP_MS, @MESAJ1_MN_MS, @MESAJ1_MX_MS, @MESAJ1_IDLE_METIN, @MESAJ1_FLAG
	union all
	select	@INSERTED_OLAY_ID, getdate(), @MESAJ2_METIN, @MESAJ2_EXP_MS, @MESAJ2_MN_MS, @MESAJ2_MX_MS, @MESAJ2_IDLE_METIN, @MESAJ2_FLAG

	insert into OLAY_CEVAP
			(CEVAP_OLAY_ID, CEVAP_ZAMAN, CEVAP_IO, CEVAP_SES_TIP, CEVAP_SES_NFO, CEVAP_FLAG, CEVAP_LED)
	select	@INSERTED_OLAY_ID, getdate(), @CEVAP_IO, @CEVAP_SES_TIP, @CEVAP_SES_NFO, @CEVAP_FLAG, @CEVAP_LED

	--*******************************************************************************
	select	'{' +
				'"Mesaj1": {' +
					'"MESAJ_METIN": {' +
						'"Text": "' + isnull(@MESAJ1_METIN,'') + '"' +
					'},' +
					'"MESAJ_EXP_MS": "' + cast(@MESAJ1_EXP_MS as varchar) + '",' +
					'"MESAJ_MN_MS": "' + cast(@MESAJ1_MN_MS as varchar) + '",' +
					'"MESAJ_MX_MS": "' + cast(@MESAJ1_MX_MS as varchar) + '",' +
					'"MESAJ_IDLE_METIN": {' +
						'"Text": "' + isnull(@MESAJ1_IDLE_METIN,'') + '"' +
					'},' +
					'"MESAJ_FLAG": "' + cast(@MESAJ1_FLAG as varchar) + '"' +
				'},' + 
	            '"Mesaj2": {' +
					'"MESAJ_METIN": {' +
						'"Text": "' + isnull(@MESAJ2_METIN,'') + '"' +
					'},' +
					'"MESAJ_EXP_MS": "' + cast(@MESAJ2_EXP_MS as varchar) + '",' +
					'"MESAJ_MN_MS": "' + cast(@MESAJ2_MN_MS as varchar) + '",' +
					'"MESAJ_MX_MS": "' + cast(@MESAJ2_MX_MS as varchar) + '",' +
					'"MESAJ_IDLE_METIN": {' +
						'"Text": "' + isnull(@MESAJ2_IDLE_METIN,'') + '"' +
					'},' +
					'"MESAJ_FLAG": "' + cast(@MESAJ2_FLAG as varchar) + '"' +
				'}' +
			'}' as Mesaj_JSON,
	getdate() as CEVAP_ZAMAN,
	@CEVAP_IO as CEVAP_IO,
	@CEVAP_SES_TIP as CEVAP_SES_TIP,
	@CEVAP_SES_NFO as CEVAP_SES_NFO,
	@CEVAP_FLAG as CEVAP_FLAG,
	@CEVAP_LED as CEVAP_LED
	--*******************************************************************************

go


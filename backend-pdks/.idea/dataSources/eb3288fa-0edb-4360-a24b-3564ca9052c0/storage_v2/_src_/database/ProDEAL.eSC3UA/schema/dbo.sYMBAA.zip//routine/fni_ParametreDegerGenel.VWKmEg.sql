

CREATE FUNCTION [dbo].[fni_ParametreDegerGenel] 
(
	@ParametreAd nvarchar(100),@ParametreVarsayilan nvarchar(100)
)
RETURNS nvarchar(MAX)
AS
BEGIN
	DECLARE @Result nvarchar(MAX)

	SELECT TOP (1) @Result=PD.PARAMETRE_DEGERI
		FROM ZONGULDAK_GENEL..TblPARAMETRE AS P (NOLOCK) 
		INNER JOIN ZONGULDAK_GENEL..TblPARAMETRE_DEGER AS PD (NOLOCK) ON P.PARAMETRE_ID = PD.PARAMETRE_ID
		WHERE (P.PARAMETRE_AD = @ParametreAd) AND (PD.SAHIP_NO = 0)
		ORDER BY PD.PARAMETRE_SEVIYESI
	IF @Result IS NULL Set @Result= @ParametreVarsayilan
	RETURN @Result

END


go




CREATE PROCEDURE [dbo].[SMS_Gonder] (@Mesaj nvarchar(1024), @Telefonlar varchar(512))
AS 
Begin

--SMS_Gonder 'AHMET DENEME 5','05536124070,05536124070'

declare @smsuser varchar(30) = dbo.fni_ParametreDegerGenel('SMS_USERNAME','');
declare @smspass nvarchar(30) = dbo.fni_ParametreDegerGenel('SMS_PASSWORD','');
declare @smssender varchar(30) = dbo.fni_ParametreDegerGenel('SMS_SENDER','');
declare @smsmusterino varchar(30) = dbo.fni_ParametreDegerGenel('SMS_MUSTERINO','');
declare @smsusercode varchar(30) = dbo.fni_ParametreDegerGenel('SMS_USERCODE','');
declare @smsaccountid varchar(30) = dbo.fni_ParametreDegerGenel('SMS_ACCOUNTID','');
declare @SmsFirma varchar(50) = dbo.fni_ParametreDegerGenel('SMS_FIRMA',''); 
declare @smsplatformid varchar(30) = dbo.fni_ParametreDegerGenel('SMS_PLATFORMID','');
declare @smschannelcode varchar(30) = dbo.fni_ParametreDegerGenel('SMS_CHANNELCODE','');

Declare @Object Int;
Declare @ret INT;
Declare @TmpByte tinyint;
Declare @status NVARCHAR(32);
Declare @statusText NVARCHAR(32);
Declare @SONUC_METIN nvarchar(1024);
declare @TblTel table (Tel nvarchar(100));
declare @Tel varchar(11);

Exec @ret = sp_OACreate 'ProDealC.ClsTools', @Object OUT;
if @ret = 0 
begin

	insert into @TblTel (Tel)
	select Items from dbo.Split (@Telefonlar, ',')

	DECLARE TblTel_Cursor CURSOR FOR
	SELECT Tel FROM @TblTel
  
	OPEN TblTel_Cursor;
  
	FETCH NEXT FROM TblTel_Cursor
	INTO @Tel

	WHILE @@FETCH_STATUS = 0
	BEGIN
		Exec @ret = sp_OAMethod @Object, 'SMS_Gonder', @TmpByte OUTPUT
						,@SMSMetni=@Mesaj
						,@CepTel=@Tel
						,@smsuser=@smsuser
						,@smspass=@smspass
						,@smssender=@smssender
						,@smsmusterino=@smsmusterino
						,@smsusercode=@smsusercode
						,@smsaccountid=@smsaccountid
						,@SmsFirma=@SmsFirma
						,@smsplatformid=@smsplatformid
						,@smschannelcode=@smschannelcode
						;
		FETCH NEXT FROM TblTel_Cursor
		INTO @Tel;
	END  
	CLOSE TblTel_Cursor;  
	DEALLOCATE TblTel_Cursor;

end
if @ret <> 0 
	 EXEC sp_OAGetErrorInfo @object;
else
	PRINT @SONUC_METIN

End
go



-- ---------------- CepTelFormatDuzenle ----------------------
create function [dbo].[CepTelFormatDuzenle] (@CEP_TEL_NO nvarchar(50)) returns nvarchar(10)
begin   
  declare @FORMATLI_CEP_TEL_NO nvarchar(10)

  -- Varsa BOSLUKLAR silinir
  select @CEP_TEL_NO = replace(@CEP_TEL_NO, ' ', '')
  
  -- Varsa Parantez (() silinir
  select @CEP_TEL_NO = replace(@CEP_TEL_NO, '(', '')
  
  -- Varsa Parantez ()) silinir
  select @CEP_TEL_NO = replace(@CEP_TEL_NO, ')', '')

  -- Varsa TIRELER (-) silinir
  select @CEP_TEL_NO = replace(@CEP_TEL_NO, '-', '')

  -- Varsa ULKE KODU (+90) silinir
  select @CEP_TEL_NO = replace(@CEP_TEL_NO, '+90', '')

  -- CEP NO Bilgisinin Basinda '90' varsa, siler
  if(left(@CEP_TEL_NO, 2) = '90')
  begin
    select @CEP_TEL_NO = substring(@CEP_TEL_NO, 3, len(@CEP_TEL_NO) - 2)
  end
  
  -- CEP NO Bilgisinin Basinda '0' varsa, siler
  if(left(@CEP_TEL_NO, 1) = '0')
  begin
    select @CEP_TEL_NO = substring(@CEP_TEL_NO, 2, len(@CEP_TEL_NO) - 1)
  end
  
  -- FORMATLI Deger Atanir
  select @FORMATLI_CEP_TEL_NO = left(@CEP_TEL_NO, 10)
  
  return @FORMATLI_CEP_TEL_NO
end

go


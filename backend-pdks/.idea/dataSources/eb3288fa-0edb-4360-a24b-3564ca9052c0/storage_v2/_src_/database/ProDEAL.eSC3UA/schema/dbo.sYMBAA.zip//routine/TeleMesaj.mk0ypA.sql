

CREATE procedure [dbo].[TeleMesaj] (@ChatID varchar(20), @MessageStr nvarchar(1024), @BotToken as nvarchar(256), @SonucMetin as nvarchar(1024)='') as

--[TeleMesaj] '-422240687', 'TESTTTT', ''

set nocount on

Declare @Object Int;
Declare @ret INT;
Declare @TmpByte tinyint;
Declare @status NVARCHAR(32);
Declare @statusText NVARCHAR(32);
Declare @SONUC_METIN NVARCHAR(32);

Exec @ret = sp_OACreate 'ProDealC.ClsTools', @Object OUT;
if @ret = 0 
	Exec @ret = sp_OAMethod @Object, 'TelegramMesaj', @TmpByte OUTPUT
					,@CHAT_ID=@ChatID
					,@MessageStr=@MessageStr
					,@BOT_TOKEN=@BotToken
					,@SONUC_METIN=@SonucMetin OUTPUT;

if @ret <> 0 
	 EXEC sp_OAGetErrorInfo @object;
else
	PRINT @SONUC_METIN


go


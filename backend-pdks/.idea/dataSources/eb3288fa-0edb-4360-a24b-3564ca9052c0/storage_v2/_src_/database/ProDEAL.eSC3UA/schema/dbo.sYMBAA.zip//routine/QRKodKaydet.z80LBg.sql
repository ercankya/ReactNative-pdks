

--QRKodKaydet '444','10',1

CREATE procedure [dbo].[QRKodKaydet] (@QRKod varchar(128), @DeviceID varchar(64), @Status tinyint) as

	declare @INSERTED_OLAY table (item_id integer);
	declare @INSERTED_OLAY_ID int;
	--*****************************************************************************
	insert into item
			(acces_state, deviceid, qrcode_str)
	output inserted.item_id
	into @INSERTED_OLAY
	values  (@Status, @DeviceID, @QRKod);
	--******************************************
	select @INSERTED_OLAY_ID = item_id from @INSERTED_OLAY;
	--*****************************************************************************

	select	'{
				"ILETI":"' + cast(isnull(@INSERTED_OLAY_ID,'') as varchar) + ' id numarası ile kaydınız yapılmıştır."
			}' as Mesaj_JSON


go


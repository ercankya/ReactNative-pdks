

-- --------------------- ConvertMinuteToTimeStr ---------------------------------------------
create function [dbo].[ConvertMinuteToTimeStr](@TIME integer) returns varchar(30)
 begin
   declare @SONUC as varchar(30)
   declare @SAAT as varchar(30)
   declare @DAKIKA as varchar(30)
   declare @SANIYE as varchar(30)
   set @SONUC = ''

   if(isnull(@TIME, -987654321) <> -987654321)
   begin
     if(@TIME < 0)
     begin
       set @SONUC = '-'
       set @TIME = @TIME * -1
     end
     if((@TIME / 60) > 99)
     begin
       set @SAAT = right('0' + cast(@TIME / 60 as varchar), 3)
     end
     else
     begin
       set @SAAT = right('0' + cast(@TIME / 60 as varchar), 2)
     end

     set @DAKIKA = right('0' + cast(@TIME % 60 as varchar), 2)
     set @SANIYE = '00'

     set @SONUC = @SONUC + @SAAT + ':' + @DAKIKA + ':' + @SANIYE
   end
   return @SONUC
 end
go




CREATE PROCEDURE [dbo].[GetHastaTemasDurumu]
@HastaKodu int=-4,
@HastaKimlikNo varchar(11),
@HekimKimlikNo varchar(11)='',
@SonucKodu tinyint output,
@RiskBasTrh varchar(10) OUTPUT,
@RiskBitTrh varchar(10) OUTPUT,
@ShowRS bit=0
as 
begin
	--Declare @SonucKodu tinyint=0;
	Declare @Object Int;
	Declare @KullaniciAdi varchar(20)=dbo.fni_ParametreDegerGenel('SAGLIKNET_VER2_KULLANICI_KODU','');
	Declare @Sifre varchar(20)=dbo.fni_ParametreDegerGenel('SAGLIKNET_VER2_KULLANICI_SIFRE','');
	Declare @UygulamaKodu varchar(40)=dbo.fni_ParametreDegerGenel('SAGLIKNET_VER2_FIRMA_KODU', 'C740D0288ED6C45FE0407C0A04162BDD');
	Declare @responseText Varchar(8000);
	Declare @ret INT;
	Declare @status NVARCHAR(32);
	Declare @statusText NVARCHAR(32);

	declare @SQL nvarchar(max);
	declare @HastamDB as varchar(32) = 'ZONGULDAK_HASTAM'; --Parametreye bağla

	Declare @URL nvarchar(500)= 'https://ussservis.saglik.gov.tr/api/OzellikliIzlem/GetHastaTemasDurumu?TcKimlikNo='

	SET @URL=@URL + @HastaKimlikNo
	If @HekimKimlikNo <> '' SET @URL = @URL + '&HekimKimlikNo=' + @HekimKimlikNo

	Exec @ret = sp_OACreate 'WinHttp.WinHttpRequest.5.1', @Object OUT;
	if @ret = 0 Exec @ret = sp_OAMethod @Object, 'open', NULL, 'get', @URL,  'false'
	if @ret = 0 Exec @ret = sp_OAMethod @Object, 'setRequestHeader', NULL, 'Content-type', 'application/json';
	if @ret = 0 Exec @ret = sp_OAMethod @Object, 'setRequestHeader', NULL, 'Accept', 'application/json';
	if @ret = 0 Exec @ret = sp_OAMethod @Object, 'setRequestHeader', NULL, 'KullaniciAdi', @KullaniciAdi;
	if @ret = 0 Exec @ret = sp_OAMethod @Object, 'setRequestHeader', NULL, 'Sifre', @Sifre;
	if @ret = 0 Exec @ret = sp_OAMethod @Object, 'setRequestHeader', NULL, 'UygulamaKodu', @UygulamaKodu;
	if @ret = 0 Exec @ret = sp_OAMethod @Object, 'send'
	if @ret = 0 EXEC @ret = sp_OAGetProperty @Object, 'status', @status OUT;
	if @ret = 0 EXEC @ret = sp_OAGetProperty @Object, 'statusText', @statusText OUT;
	if @ret = 0 EXEC @ret = sp_OAGetProperty @Object, 'responseText', @responseText OUT;

	--PRINT 'Status: ' + @status + ' (' + @statusText + ')';
	--PRINT 'Response text: ' + @responseText;
	EXEC @ret = sp_OADestroy @Object;

	if PATINDEX( '{"durum":1,"sonuc":{"durum":"Dikkat%',@responseText)>0	
		SET @SonucKodu=2	
	else if PATINDEX('{"durum":1,"sonuc":null%',@responseText)>0
		SET @SonucKodu=1
	else if PATINDEX('{"durum":_,"sonuc"%',@responseText)>0
		SET @SonucKodu=3

	if PATINDEX( '{"durum":1,"sonuc":{"durum":"Dikkat%',@responseText)>0
		SET @RiskBasTrh=SUBSTRING(@responseText,CHARINDEX('"temasRiskiBaslamaZamani":',@responseText,0)+27,10)

	if PATINDEX( '{"durum":1,"sonuc":{"durum":"Dikkat%',@responseText)>0
		SET @RiskBitTrh=SUBSTRING(@responseText,CHARINDEX('"temasRiskiBitisZamani":',@responseText,0)+25,10)

	--**********************************************
	set @SQL = '
	INSERT INTO ' + @HastamDB + '..TblRiskSorgu (RS_HstKod, RS_TC, RS_Zmn, RS_SonucKodu, RS_SonucStr, RS_EkBilgi)
	VALUES (@HastaKodu, @HastaKimlikNo , GETDATE(), @SonucKodu, @responseText, ''HostName:'' + HOST_NAME())';
	--***
	exec sp_executesql @SQL, N'@HastaKodu int, @HastaKimlikNo varchar(11), @SonucKodu tinyint, @responseText varchar(8000)',
							 @HastaKodu = @HastaKodu, @HastaKimlikNo = @HastaKimlikNo, @SonucKodu = @SonucKodu, @responseText = @responseText; 
	--**********************************************

	if @ShowRS=1
		SELECT @ret AS Ret, @status AS Status, @statusText AS StatusText, @responseText AS ResponseText, @SonucKodu AS SonucKodu,@RiskBasTrh AS RiskBasTrh,@RiskBitTrh AS RiskBitTrh
end
go




-- ---------------------------- Split -------------------------------------
create function [dbo].[Split](@STRING nvarchar(4000), @Delimiter char(1)) returns @Results table (Items nvarchar(4000)) as
begin
  declare @index integer
  declare @SLICE nvarchar(4000)
  select @index = 1

  if @STRING is null return
  while @index !=0
  begin
    select @index = charindex(@Delimiter,@STRING)

    if @index !=0
        select @SLICE = rtrim(ltrim(left(@STRING,@index - 1)))
    else
        select @SLICE = rtrim(ltrim(@STRING))

    insert into @Results(Items) VALUES(@SLICE)

    select @STRING = right(@STRING,len(@STRING) - @index)

    if len(@STRING) = 0 BREAK
  end
  return
end
go


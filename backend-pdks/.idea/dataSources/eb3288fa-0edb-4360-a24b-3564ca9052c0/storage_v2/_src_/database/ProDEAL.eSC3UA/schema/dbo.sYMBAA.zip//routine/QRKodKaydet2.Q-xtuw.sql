

CREATE procedure [dbo].[QRKodKaydet2] (@QRKod varchar(128), @DeviceID varchar(64), @Status tinyint, @Mesaj_JSON varchar(1024) output, @Cevap_SQL varchar(1024) output) as

--declare @Mesaj_JSON varchar(1024); declare @Cevap_SQL varchar(1024); exec QRKodKaydet2 '6d5c3201c1075b1b1bbb095e8dc30b58','998e4d3681fe9cbc', 0, @Mesaj_JSON output, @Cevap_SQL output; select @Mesaj_JSON, @Cevap_SQL;
--declare @Mesaj_JSON varchar(1024); declare @Cevap_SQL varchar(1024); exec QRKodKaydet2 '48ca9aa0e7c0289fcdb00aea3d1ebd34','998e4d3681fe9cbc', 0, @Mesaj_JSON output, @Cevap_SQL output; select @Mesaj_JSON, @Cevap_SQL;

	declare @TmpTable table (Mesaj_JSON nvarchar(1024), CEVAP_ZAMAN datetime, CEVAP_IO nchar(256), CEVAP_SES_TIP tinyint, CEVAP_SES_NFO nvarchar(512), CEVAP_FLAG tinyint, CEVAP_LED tinyint, CEVAP_SQL nvarchar(512));
	declare @INSERTED_OLAY table (OLAY_ID integer);
	declare @INSERTED_OLAY_ID int;
	declare @QRKOD_TERMINAL_ID int;
	declare @TERMINAL_SERI varchar(32);
	declare @SQL nvarchar(1024);
	--*************************************************************
	select @QRKOD_TERMINAL_ID = TERMINAL.TERMINAL_ID, @TERMINAL_SERI = TERMINAL.TERMINAL_SERI
	from KOD
	inner join TERMINAL on TERMINAL.TERMINAL_ID = KOD.TERMINAL_ID
	where KOD_STRING = @QRKod
	and   getdate() between KOD_BASLANGIC_ZAMANI and KOD_BITIS_ZAMANI;
	--*************************************************************
	if (isnull(@QRKOD_TERMINAL_ID,0) > 0)
		begin
		set @SQL = 'ProPI_DBOS_v1 ''' + @TERMINAL_SERI + ''', ''' + @DeviceID + ''', null, '''', '''', 0';
		insert into @TmpTable exec (@SQL);
		select @Mesaj_JSON = Mesaj_JSON, @Cevap_SQL = Cevap_SQL from @TmpTable
		end
	else
		begin
		select	@Mesaj_JSON = '{
								   "Mesaj3":{
									  "MESAJ_METIN":{
										 "Text":"QRKod hatalıdır."
									  },
									  "MESAJ_EXP_MS":"1000",
									  "MESAJ_MN_MS":"1000",
									  "MESAJ_MX_MS":"3000",
									  "MESAJ_FLAG":"0"
								   }
								}',
				@Cevap_SQL = ''
		end

go



CREATE procedure [dbo].[Hareketlerim] (@DeviceID varchar(64), @BasTrh datetime, @BitTrh datetime,@MsgSTR varchar(max) output) as
	--*****************************************************************************
	select @MsgSTR =coalesce(@MsgSTR+char(10), '') + cast(convert(datetime,OLAY.OLAY_ZAMAN,104) as nvarchar(max))
						from OLAY
						where OLAY_SERI = @DeviceID
						and   cast(OLAY_ZAMAN as date) between @BasTrh and @BitTrh
	--*****************************************************************************
	select @MsgSTR=@MsgSTR


	--aşağıdaki sorgunun dönütünü json çevirdim ama serviste json görünmüyor.şimdilik askıya aldık.

	--ALTER procedure [dbo].[Hareketlerim] (@DeviceID varchar(64), @BasTrh datetime, @BitTrh datetime,@MsgSTR varchar(max) output) as
	----*****************************************************************************
	--select @MsgSTR =coalesce(@MsgSTR +char(13) +char(10), '') +'{' +'"deviceID"'+':'+'"' +OLAY.OLAY_SERI+ '"'+ ','+ '"dateTime"'+':'+'"' +cast(convert(datetime,OLAY.OLAY_ZAMAN,104) as nvarchar(max))+'"'+'}' + ','
	--					from OLAY
	--					where OLAY_SERI = @DeviceID
	--					and   cast(OLAY_ZAMAN as date) between @BasTrh and @BitTrh
	----*****************************************************************************
	--select @MsgSTR='{'+@MsgSTR+'}'
go







CREATE procedure [dbo].[ProPI_DBOS2] (@OLAY_ID int) as
	set nocount off
	--***************************
	waitfor delay '00:00:10';
	--***************************
	declare @SQL nvarchar(max);
	declare @KART_ID integer;
	declare @TERMINAL_ID integer;
	declare @OLAY_ZAMAN datetime;
	declare @OLAY_KAYIT_ZAMAN datetime;
	declare @DELETE bit;
	--***************************
	--Parametreler
	--declare @OlayDuzeltmeSure smallint = 60;
	--declare @CovidSonucBildirimTelegramGrupKod varchar(20) = '-1001283510321';
	--declare @CovidSonucBildirimSmsTelNolar varchar(256) = '05325046290,05056160859,05453591133,05536043865';
	--declare @GecKalanErkenCikanBildirimTelegramGrupKod varchar(20) = '-1001283510321'; -- DİĞER  6
	--declare @GecKalanErkenCikanBildirimTelegramGrupKod1 varchar(20) = '-1001482962877'; -- İDARİ / TEKNİK  1
	--declare @GecKalanErkenCikanBildirimTelegramGrupKod2 varchar(20) = '-366186682'; -- 4/D GÜVENLİK  2
	--declare @GecKalanErkenCikanBildirimTelegramGrupKod3 varchar(20) = '-390482966'; -- HEKİM  3
	--declare @GecKalanErkenCikanBildirimTelegramGrupKod4 varchar(20) = '-482829288'; -- 4/D DİŞ KLİNİK DESTEK  4
	--declare @GecKalanErkenCikanBildirimTelegramGrupKod5 varchar(20) = '-499465576'; -- 4/D GENEL DESTEK  5
	--declare @GecKalanErkenCikanBildirimTelegramGrupKod7 varchar(20) = '-456095349'; -- 4/D İŞÇİ  7
	--declare @GecKalanErkenCikanBildirimTelegramGrupKod varchar(20) = '';
	--declare @GecKalanErkenCikanBildirimTelegramGrupKod1 varchar(20) = '';
	--declare @GecKalanErkenCikanBildirimTelegramGrupKod2 varchar(20) = '';
	--declare @GecKalanErkenCikanBildirimTelegramGrupKod3 varchar(20) = '';
	--declare @GecKalanErkenCikanBildirimTelegramGrupKod4 varchar(20) = '';
	--declare @GecKalanErkenCikanBildirimTelegramGrupKod5 varchar(20) = '';
	--declare @GecKalanErkenCikanBildirimTelegramGrupKod7 varchar(20) = '';
	--declare @GecKalanErkenCikanBildirimSms bit = 0;
	--declare @GecKalanErkenCikanBildirimSmsKendine bit = 0;
	--declare @GecKalanErkenCikanBildirimSmsTelNolar varchar(256) = '';
	--declare @BOT_Token varchar(60) = dbo.fni_ParametreDegerGenel('T_BOT_TOKEN', '1057789908:AAFabkbil5eAW0_GGr8otxSYxvvwH1RsNuI');
	declare @DealDB as varchar(32) = 'DEAL_INEGOL';
	declare @HastamDB as varchar(32) = 'ZONGULDAK_HASTAM';
	--***************************
	--AHMET PARAMETRELER
	declare @OlayDuzeltmeSure smallint = 60;
	declare @CovidSonucBildirimTelegramGrupKod varchar(20) = '-420981850';
	declare @GecKalanErkenCikanBildirimTelegramGrupKod varchar(20) = '-420981850';
	declare @GecKalanErkenCikanBildirimTelegramGrupKod1 varchar(20) = '-420981850';
	declare @GecKalanErkenCikanBildirimTelegramGrupKod2 varchar(20) = '-420981850';
	declare @GecKalanErkenCikanBildirimTelegramGrupKod3 varchar(20) = '-420981850';
	declare @GecKalanErkenCikanBildirimTelegramGrupKod4 varchar(20) = '-420981850';
	declare @GecKalanErkenCikanBildirimTelegramGrupKod5 varchar(20) = '420981850';
	declare @GecKalanErkenCikanBildirimTelegramGrupKod7 varchar(20) = '420981850';
	declare @CovidSonucBildirimSmsTelNolar varchar(256) = '';
	declare @GecKalanErkenCikanBildirimSms bit = 0;
	declare @GecKalanErkenCikanBildirimSmsKendine bit = 0;
	declare @GecKalanErkenCikanBildirimSmsTelNolar varchar(256) = '';
	declare @BOT_Token varchar(60) = '1042706355:AAGagahYtvK1sF-t4iVw8i_bwLQ2iDCTN34'; --Ahmet
	--***************************
	declare @MESAJ_STR nvarchar(500), @MESAJ_STR_TRSIZ nvarchar(500);
	declare @SONUC as integer, @SONUC2 as integer;
	declare @COVID_SONUC as tinyint;
	declare @KART_TC as varchar(11), @KART_ATAMA_ETIKET as nvarchar(100);
	declare @PDKS_ZAMAN_ID as integer, @GIRIS_ZAMAN_INT as integer, @CIKIS_ZAMAN_INT as integer, @OLAY_ZAMAN_INT as integer, @OLAY_INOUT as tinyint, @OLAY_ID_SON as integer
	declare @PERSONEL_TUR_ID as integer;
	declare @GEC_KALDI as bit, @ERKEN_CIKTI as bit;
	declare @OLAY_SONUC_KOD1 as varchar(64), @OLAY_SONUC_KOD2 as varchar(64);
	declare @GECKALANBILDIRIMGONDERILMIS as bit;
	--*************************************************************************************************
	select @KART_ID = OLAY_KART_ID, @TERMINAL_ID = OLAY_TERMINAL_ID, @OLAY_KAYIT_ZAMAN = OLAY_KAYIT_ZAMAN,
			@OLAY_ZAMAN = OLAY_ZAMAN, @OLAY_INOUT = OLAY_INOUT, @OLAY_ZAMAN_INT = dbo.ConvertTimeStrToMinute(left(cast(OLAY_ZAMAN as time),5))
	from OLAY (nolock)
	where OLAY_ID = @OLAY_ID;
	--*************************************************************************************************
	if (isnull(@KART_ID,0)>0 and isnull(@TERMINAL_ID,0)>0)
		set @DELETE = (select distinct 1 from OLAY (nolock) where OLAY_ID > @OLAY_ID and OLAY_KART_ID = @KART_ID and OLAY_TERMINAL_ID = @TERMINAL_ID and OLAY_KAYIT_ZAMAN <= dateadd(second,@OlayDuzeltmeSure,@OLAY_KAYIT_ZAMAN) and isnull(PSF,0) = 0);
	--*************************************************************************************************
	if (@DELETE = 1)
		update OLAY set PSF = 1 from OLAY where OLAY_ID = @OLAY_ID;
	else
		begin
		if (isnull(@KART_ID,0)>0 and isnull(@TERMINAL_ID,0)>0)
			begin
			--*************************************************************************************************
			select @KART_TC = KART_ILISKI_ID, @KART_ATAMA_ETIKET = KART_ATAMA_ETIKET from KART_ATAMA (nolock) where KART_ID = @KART_ID and @OLAY_ZAMAN between ATAMA_BASLANGIC_ZAMANI and ATAMA_BITIS_ZAMANI and KART_ATAMA.KART_ILISKI_TURU = 1;
			--*************************************************************************************************
			if (len(isnull(@KART_TC,0)) = 11)
				begin
				set @COVID_SONUC = 0;
				--exec [dbo].[GetHastaTemasDurumu] @HastaKimlikNo = @KART_TC, @SonucKodu = @COVID_SONUC output, @RiskBasTrh = @SONUC output, @RiskBitTrh = @SONUC2 output;
				--*******************************
				insert into OLAY_SONUC (OLAY_ID, OLAY_SONUC_KOD, OLAY_SONUC_SONUC)
								values (@OLAY_ID, 'COVID_SONUC', case @COVID_SONUC when 3 then '3 (HATA)' when 2 then '2 (TEMASLI)' when 1 then '1 (ONAY)' else 'HATALI CEVAP' end);
				--***********************************************************************************************************
				--Giriş/Çıkış yapması gereken zamanı ve personel türünü bul
				set @SQL = '
				select @GIRIS_ZAMAN_INT = (pz.ZAMAN1 + isnull(pz.ARTIDEGER1,0)), @CIKIS_ZAMAN_INT = (pz.ZAMAN4 - isnull(pz.EKSIDEGER4,0)), @PERSONEL_TUR_ID = p.PERSONEL_TUR_ID, @PDKS_ZAMAN_ID = pz.PDKS_ZAMAN_ID
				from ' + @DealDB + '..KIMLIK (nolock) as k
				inner join ' + @DealDB + '..PERSONEL (nolock) as p on k.KIMLIK_ID = p.KIMLIK_ID and isnull(k.PSF_ID, 0) = 0
				left join ' + @DealDB + '..PERSONEL_TUR (nolock) as pt on p.PERSONEL_TUR_ID = pt.PERSONEL_TUR_ID
				left join (	select pz.*, pza.PERSONEL_TUR_ID
							from ' + @DealDB + '..PDKS_ZAMAN (nolock) as pz
							left join ' + @DealDB + '..PDKS_ZAMAN_ATAMA (nolock) as pza on pz.PDKS_ZAMAN_ID = pza.PDKS_ZAMAN_ID and isnull(pza.PSF_ID, 0) = 0
																	                   and @OLAY_ZAMAN between pza.BASLANGIC_TRH and pza.BITIS_TRH
							where isnull(pz.PSF_ID, 0) = 0) as pz on p.PERSONEL_TUR_ID = ISNULL(pz.PERSONEL_TUR_ID,p.PERSONEL_TUR_ID)
				where isnull(k.PSF_ID, 0) = 0
				and   k.KIMLIK_TC_NO = @KART_TC
				group by pz.ZAMAN1, pz.ZAMAN4, p.PERSONEL_TUR_ID, pz.ARTIDEGER1, pz.EKSIDEGER4, pz.PDKS_ZAMAN_ID';
				--***
				exec sp_executesql @SQL, N'@OLAY_ZAMAN datetime, @KART_TC varchar(11), @GIRIS_ZAMAN_INT integer output, @CIKIS_ZAMAN_INT integer output, @PERSONEL_TUR_ID integer output, @PDKS_ZAMAN_ID integer output',
										   @OLAY_ZAMAN = @OLAY_ZAMAN, @KART_TC = @KART_TC, @GIRIS_ZAMAN_INT = @GIRIS_ZAMAN_INT output, @CIKIS_ZAMAN_INT = @CIKIS_ZAMAN_INT output, @PERSONEL_TUR_ID = @PERSONEL_TUR_ID output, @PDKS_ZAMAN_ID = @PDKS_ZAMAN_ID output; 
				--*******************************
				insert into OLAY_SONUC (OLAY_ID, OLAY_SONUC_KOD, OLAY_SONUC_SONUC)
								values (@OLAY_ID, 'PERSONEL_TUR_ID', @PERSONEL_TUR_ID);
				insert into OLAY_SONUC (OLAY_ID, OLAY_SONUC_KOD, OLAY_SONUC_SONUC)
								values (@OLAY_ID, 'KART_TC', @KART_TC);
				insert into OLAY_SONUC (OLAY_ID, OLAY_SONUC_KOD, OLAY_SONUC_SONUC)
								values (@OLAY_ID, 'GIRIS_ZAMAN_INT', @GIRIS_ZAMAN_INT);
				insert into OLAY_SONUC (OLAY_ID, OLAY_SONUC_KOD, OLAY_SONUC_SONUC)
								values (@OLAY_ID, 'CIKIS_ZAMAN_INT', @CIKIS_ZAMAN_INT);
				insert into OLAY_SONUC (OLAY_ID, OLAY_SONUC_KOD, OLAY_SONUC_SONUC)
								values (@OLAY_ID, 'PDKS_ZAMAN_ID', @PDKS_ZAMAN_ID);
				--*******************************
				--***********************************************************************************************************
				--Covid durumu TEMAS ise bildirim gönder
				if (@COVID_SONUC=2)
					begin
					set @MESAJ_STR = @KART_TC + ' - ' + isnull(@KART_ATAMA_ETIKET,'(Ad/Soyad bulunamadı)') + ' Temas tespit edildi';
					set @MESAJ_STR_TRSIZ = dbo.Turkce_Kaldir(@MESAJ_STR);
					--**********************************************
					if (@CovidSonucBildirimTelegramGrupKod <> '')
						begin
						exec [TeleMesaj] @CovidSonucBildirimTelegramGrupKod, @MESAJ_STR, @BOT_Token;
						--*******************************
						insert into OLAY_SONUC (OLAY_ID, OLAY_SONUC_KOD, OLAY_SONUC_SONUC)
										values (@OLAY_ID, 'COVID_SONUC_TELEGRAM_MESAJ', @MESAJ_STR);
						insert into OLAY_SONUC (OLAY_ID, OLAY_SONUC_KOD, OLAY_SONUC_SONUC)
										values (@OLAY_ID, 'COVID_SONUC_TELEGRAM_GRUPKODU', @CovidSonucBildirimTelegramGrupKod);
						--*******************************
						end
					--**********************************************
					if (@CovidSonucBildirimSmsTelNolar <> '')
						begin
						exec [SMS_Gonder] @Mesaj = @MESAJ_STR_TRSIZ, @Telefonlar = @CovidSonucBildirimSmsTelNolar;
						--*******************************
						insert into OLAY_SONUC (OLAY_ID, OLAY_SONUC_KOD, OLAY_SONUC_SONUC)
										values (@OLAY_ID, 'COVID_SONUC_SMS_MESAJ', @MESAJ_STR_TRSIZ);
						insert into OLAY_SONUC (OLAY_ID, OLAY_SONUC_KOD, OLAY_SONUC_SONUC)
										values (@OLAY_ID, 'COVID_SONUC_SMS_TELNO', @CovidSonucBildirimSmsTelNolar);
						--*******************************
						end
					--**********************************************
					end
				--*****************************************************************************
				if (@GecKalanErkenCikanBildirimSms = 1)
					exec PersonelTurYetkiliTelStr @PERSONEL_TUR_ID = @PERSONEL_TUR_ID, @sonuc= @GecKalanErkenCikanBildirimSmsTelNolar output;
				--******************************
				set @MESAJ_STR = '';
				set @MESAJ_STR_TRSIZ = '';
				--
				if (@OLAY_INOUT = 0) --Giriş ise
					begin
					--**********************************************
					--Bugün ilk girişi ise bildirim gönder, sonrasında gönderme
					--set @GECKALANBILDIRIMGONDERILMIS = (select distinct 1
					--									from OLAY (nolock)
					--									--inner join OLAY_SONUC (nolock) on OLAY.OLAY_ID = OLAY_SONUC.OLAY_ID and OLAY_SONUC.OLAY_SONUC_KOD in ('GEC_KALAN_TELEGRAM_MESAJ','GEC_KALAN_SMS_MESAJ')
					--									where OLAY.OLAY_KART_ID = @KART_ID
					--									and   OLAY.OLAY_ID < @OLAY_ID
					--									and   isnull(OLAY.PSF,0) = 0
					--									and   isnull(OLAY.OLAY_INOUT,0) = 0
					--									--and   isnull(OLAY.OLAY_TERMINAL_ID,0) = @TERMINAL_ID
					--									and   isnull(OLAY.OLAY_TERMINAL_ID,0) > 0
					--									and   OLAY.OLAY_KAYIT_ZAMAN < dateadd(second, -1 * @OlayDuzeltmeSure, @OLAY_KAYIT_ZAMAN)
					--									and   cast(OLAY_ZAMAN as date) = cast(getdate() as date));
					--**********************************************
					--Giriş yaptığı saat, giriş yapması gereken saatten büyük ise geç kaldı bildirimi gönder
					if (@OLAY_ZAMAN_INT > ISNULL(@GIRIS_ZAMAN_INT,0))
						begin
						set @GEC_KALDI = 1
						--*******************************
						insert into OLAY_SONUC (OLAY_ID, OLAY_SONUC_KOD, OLAY_SONUC_SONUC)
										values (@OLAY_ID, 'GEC_KALDI', '1');
						--*******************************
						if (isnull(@GECKALANBILDIRIMGONDERILMIS,0) = 0)
							begin
							set @MESAJ_STR = @KART_TC + ' - ' + isnull(@KART_ATAMA_ETIKET,'(Ad/Soyad bulunamadı)') + ' ' + cast(@OLAY_ZAMAN_INT - ISNULL(@GIRIS_ZAMAN_INT,0) as varchar) + ' dk geç giriş yapmıştır.' + CHAR(13)+CHAR(10) + 'Giriş saati: ' + left(cast(@OLAY_ZAMAN as time),8) + CHAR(13)+CHAR(10) + 'Giriş yapması gereken saat: ' + dbo.ConvertMinuteToTimeStr(@GIRIS_ZAMAN_INT) + CHAR(13)+CHAR(10);
							--set @MESAJ_STR = @KART_TC + ' - ' + isnull(@KART_ATAMA_ETIKET,'(Ad/Soyad bulunamadı)') + ' geç giriş yapmıştır.' + CHAR(13)+CHAR(10) + 'Giriş saati: ' + left(cast(@OLAY_ZAMAN as time),8);
							set @MESAJ_STR_TRSIZ = dbo.Turkce_Kaldir(@MESAJ_STR);
							end
						end
					end
				else if (@OLAY_INOUT = 1) --Çıkış ise
					begin
					--Çıkış yaptığı saat, çıkış yapması gereken saatten küçük ise erken çıktı bildirimi gönder
					if (@OLAY_ZAMAN_INT < ISNULL(@CIKIS_ZAMAN_INT,0))
						begin
						set @ERKEN_CIKTI = 1
						--*******************************
						insert into OLAY_SONUC (OLAY_ID, OLAY_SONUC_KOD, OLAY_SONUC_SONUC)
										values (@OLAY_ID, 'ERKEN_CIKTI', '1');
						--*******************************
						set @MESAJ_STR = @KART_TC + ' - ' + isnull(@KART_ATAMA_ETIKET,'(Ad/Soyad bulunamadı)') + ' ' + cast(ISNULL(@CIKIS_ZAMAN_INT,0) - @OLAY_ZAMAN_INT as varchar) + ' dk erken çıkış yapmıştır.' + CHAR(13)+CHAR(10) + 'Çıkış saati: ' + left(cast(@OLAY_ZAMAN as time),8) + CHAR(13)+CHAR(10) + 'Çıkış yapması gereken saat: ' + dbo.ConvertMinuteToTimeStr(@CIKIS_ZAMAN_INT) + CHAR(13)+CHAR(10);
						--set @MESAJ_STR = @KART_TC + ' - ' + isnull(@KART_ATAMA_ETIKET,'(Ad/Soyad bulunamadı)') + ' erken çıkış yapmıştır.' + CHAR(13)+CHAR(10) + 'Çıkış saati: ' + left(cast(@OLAY_ZAMAN as time),8);
						set @MESAJ_STR_TRSIZ = dbo.Turkce_Kaldir(@MESAJ_STR);
						end
					end
				--******************************
				if (isnull(@MESAJ_STR,'') <> '')
					begin
					if (@GecKalanErkenCikanBildirimTelegramGrupKod <> '')
						begin
						--**************************************************
						if (@PDKS_ZAMAN_ID = 1) -- İDARİ / TEKNİK  1
							set @GecKalanErkenCikanBildirimTelegramGrupKod = @GecKalanErkenCikanBildirimTelegramGrupKod1
						else if (@PDKS_ZAMAN_ID = 2) -- 4/D GÜVENLİK  2
							set @GecKalanErkenCikanBildirimTelegramGrupKod = @GecKalanErkenCikanBildirimTelegramGrupKod2
						else if (@PDKS_ZAMAN_ID = 3) -- HEKİM  3
							set @GecKalanErkenCikanBildirimTelegramGrupKod = @GecKalanErkenCikanBildirimTelegramGrupKod3
						else if (@PDKS_ZAMAN_ID = 4) -- 4/D DİŞ KLİNİK DESTEK  4
							set @GecKalanErkenCikanBildirimTelegramGrupKod = @GecKalanErkenCikanBildirimTelegramGrupKod4
						else if (@PDKS_ZAMAN_ID = 5)  -- 4/D GENEL DESTEK  5
							set @GecKalanErkenCikanBildirimTelegramGrupKod = @GecKalanErkenCikanBildirimTelegramGrupKod5
						else if (@PDKS_ZAMAN_ID = 7)  -- 4/D İŞÇİ
							set @GecKalanErkenCikanBildirimTelegramGrupKod = @GecKalanErkenCikanBildirimTelegramGrupKod7
						else -- DİĞER  6
							set @GecKalanErkenCikanBildirimTelegramGrupKod = @GecKalanErkenCikanBildirimTelegramGrupKod
						--**************************************************
						exec [TeleMesaj] @GecKalanErkenCikanBildirimTelegramGrupKod, @MESAJ_STR, @BOT_Token;
						--*******************************
						if (@GEC_KALDI = 1)
							begin
							set @OLAY_SONUC_KOD1 = 'GEC_KALAN_TELEGRAM_MESAJ'
							set @OLAY_SONUC_KOD2 = 'GEC_KALAN_TELEGRAM_GRUPKODU'
							end
						else if (@ERKEN_CIKTI = 1)
							begin
							set @OLAY_SONUC_KOD1 = 'ERKEN_CIKAN_TELEGRAM_MESAJ'
							set @OLAY_SONUC_KOD2 = 'ERKEN_CIKAN_TELEGRAM_GRUPKODU'
							end
						--***
						insert into OLAY_SONUC (OLAY_ID, OLAY_SONUC_KOD, OLAY_SONUC_SONUC)
										values (@OLAY_ID, @OLAY_SONUC_KOD1, @MESAJ_STR);
						insert into OLAY_SONUC (OLAY_ID, OLAY_SONUC_KOD, OLAY_SONUC_SONUC)
										values (@OLAY_ID, @OLAY_SONUC_KOD2, @GecKalanErkenCikanBildirimTelegramGrupKod);
						--*******************************
						end
					--**********************************************
					--Personelin cep numarasını bul
					if (@GecKalanErkenCikanBildirimSmsKendine = 1 and @PDKS_ZAMAN_ID <> 2)
						begin
						set @SQL = '
						select top (1) @GecKalanErkenCikanBildirimSmsTelNolar = dbo.CepTelFormatDuzenle(ILETISIM_DEGER)
						from ' + @DealDB + '..PERSONEL
						inner join ' + @DealDB + '..KIMLIK as KIMLIK on PERSONEL.KIMLIK_ID = KIMLIK.KIMLIK_ID AND isnull(KIMLIK.PSF_ID,0) = 0
						inner join ' + @DealDB + '..ILETISIM_ILISKI as ILETISIM_ILISKI on PERSONEL.KIMLIK_ID = ILETISIM_ILISKI.ILISKI_TABLO_KAYIT_ID AND ILETISIM_ILISKI.ILISKI_TABLO_AD = ''KIMLIK'' AND isnull(ILETISIM_ILISKI.PSF_ID,0) = 0
						inner join ' + @DealDB + '..ILETISIM as ILETISIM on ILETISIM_ILISKI.ILETISIM_ID = ILETISIM.ILETISIM_ID and ILETISIM_TUR_ID = 48 And ILETISIM_ALT_TUR_ID = 73  AND isnull(ILETISIM.PSF_ID,0) = 0
						where KIMLIK.KIMLIK_TC_NO = @KART_TC
						and   isnull(PERSONEL.PSF_ID,0) = 0
						order by ILETISIM.ILETISIM_ID';
						--***
						exec sp_executesql @SQL, N'@KART_TC varchar(11), @GecKalanErkenCikanBildirimSmsTelNolar varchar(11) output',
												   @KART_TC = @KART_TC, @GecKalanErkenCikanBildirimSmsTelNolar = @GecKalanErkenCikanBildirimSmsTelNolar output; 
						end
					--**********************************************
					if (@GecKalanErkenCikanBildirimSms = 1)
						if (isnull(@GecKalanErkenCikanBildirimSmsTelNolar,'') <> '')
							begin
							exec [SMS_Gonder] @Mesaj = @MESAJ_STR_TRSIZ, @Telefonlar = @GecKalanErkenCikanBildirimSmsTelNolar
							--*******************************
							if (@GEC_KALDI = 1)
								begin
								set @OLAY_SONUC_KOD1 = 'GEC_KALAN_SMS_MESAJ'
								set @OLAY_SONUC_KOD2 = 'GEC_KALAN_SMS_TELNO'
								end
							else if (@ERKEN_CIKTI = 1)
								begin
								set @OLAY_SONUC_KOD1 = 'ERKEN_CIKAN_SMS_MESAJ'
								set @OLAY_SONUC_KOD2 = 'ERKEN_CIKAN_SMS_TELNO'
								end
							--***
							insert into OLAY_SONUC (OLAY_ID, OLAY_SONUC_KOD, OLAY_SONUC_SONUC)
											values (@OLAY_ID, @OLAY_SONUC_KOD1, @MESAJ_STR_TRSIZ);
							insert into OLAY_SONUC (OLAY_ID, OLAY_SONUC_KOD, OLAY_SONUC_SONUC)
										values (@OLAY_ID, @OLAY_SONUC_KOD2, @GecKalanErkenCikanBildirimSmsTelNolar);
							--*******************************
							end
					end
				--******************************
				end
			end
		end
	--*************************************************************************************************
go

